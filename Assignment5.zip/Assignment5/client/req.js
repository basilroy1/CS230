var container=$('form.insert');

$('input#insert').click(function(){
$.ajax({
	type: 'POST',
	url: '/data.json',
	//dataTyp: 'json',
	success: function(data){
		$.each(data,function(index,item){
			$.each(data,function(key,value){
				container.append(key+":"+value+'</br>')

			});
			container.append('</br><br>');

		});
	}

});

})