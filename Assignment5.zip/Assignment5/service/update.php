<?php
include 'conn.php';
//Update record in database

$ID="";
$Name="";
$URL="";
$Description="";


$ID=$_GET['ID'];

$Name = $_GET['name'];
$URL = $_GET['url'];
$Description = $_GET['description'];

$query = "UPDATE restful SET Name='$Name' , URL='$URL' , Description='$Description' WHERE ID='$ID'";
if ($connection->query($query)) {
       $msg = array("status" =>1 , "msg" => "Record Updated successfully");
}else {
    echo "Error: " . $query . "<br>" . mysqli_error($connection);
}

$json = $msg;

header('Content-Type: application/json');
header('location: ../client/home.html');
echo json_encode($json);

@mysqli_close($conn);
?>