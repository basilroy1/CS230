<?php
include 'conn.php';
//Delete record from database
$ID="";
$msg="";
$ID = $_GET['ID'];


$query = "DELETE FROM restful WHERE ID='$ID'";
if ($connection->query($query)) {
   // $msg = array("status" =>1 , "msg" => "Record Deleted successfully");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($connection);
} 

$json = $msg;

header('content-type: application/json');
header('location: ../client/home.html');
echo json_encode($json);

@mysqli_close($conn);
?>