<?php

$connection = new mysqli("localhost", "root", "", "assignment5") or die(mysqli_error());

?>