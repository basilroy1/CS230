<?php

include 'conn.php';

//$ID="";
$Name="";
$URL="";
$Date="";
$Description="";

//ID = $_POST['ID']; 
$Date =$_POST['date']; 
$Name = $_POST['name']; 
$URL =  $_POST['url']; 
$Description = $_POST['description']; 

$now=new DateTime();
$daa=$now->format('Y-m-d H:i:s');

$sql = "INSERT INTO restful (Date,Name,URL,Description) VALUES ('$daa','$Name','$URL','$Description')";

if ($connection->query($sql) === TRUE) {
    $msg = array("status" =>1 , "msg" => "Your record inserted successfully");
} 
else {

    echo "Error: " . $sql . "<br>" . mysqli_error($connection);

}
$json = $msg;

header('Content-Type: application/data.json');

header('location:../client/home.html');

echo json_encode($json);

@mysqli_close($conn);
?>