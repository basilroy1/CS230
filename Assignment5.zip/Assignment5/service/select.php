<?php
include 'conn.php';
//Select data from database

$ID="";

$ID=$_GET['ID'];

$getData = "SELECT * FROM restful WHERE ID='$ID'";
$qur = $connection->query($getData);

while($r = mysqli_fetch_assoc($qur)){
$msg[] = array("ID" => $r['ID'], "date" => $r['Date'], "name" => $r['Name'] , "url" => $r['URL'], "description" => $r['Description']);
}
$json = $msg;

header('content-type: application/json');
echo json_encode($json,JSON_PRETTY_PRINT);

@mysqli_close($conn);

?>