-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2018 at 04:35 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assignment5`
--

-- --------------------------------------------------------

--
-- Table structure for table `restful`
--

CREATE TABLE `restful` (
  `ID` int(5) NOT NULL,
  `Date` date NOT NULL,
  `Name` varchar(255) NOT NULL,
  `URL` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restful`
--

INSERT INTO `restful` (`ID`, `Date`, `Name`, `URL`, `Description`) VALUES
(98, '0000-00-00', 'aa', 'aa', 'aa'),
(99, '0000-00-00', '12121', 'o9uijoi', 'jinijnji'),
(100, '2018-04-01', 'hi', 'ih', 'hi'),
(101, '2018-03-29', 'oppoop', 'poopop', 'opopo'),
(102, '0000-00-00', 'wewef', 'oliioi', 'jjk'),
(106, '2018-04-01', 'o', 'k', 'm'),
(108, '0000-00-00', 'uiuiuiui', 'hji', ''),
(111, '0000-00-00', 'i', 'i', 'u'),
(112, '0000-00-00', 'u', 'u', 'u'),
(114, '0000-00-00', 'basilw', 'jnkjdj ', 'j n '),
(115, '2018-04-22', 'aab', 'nm', 'nmq'),
(116, '2018-04-22', 'paul', 'lipa', 'da'),
(121, '2018-04-23', 'peterwew', 'iuhhi', 'hi'),
(122, '2018-04-23', 'ugg', '7uuu', 'uu'),
(126, '2018-04-23', 'uuuuu', 'gggg', 'bbbb'),
(127, '2018-04-23', 'pooooo', 'hhjhj', 'hjhjhjhj'),
(128, '2018-04-23', '123', '90i', '09i'),
(129, '2018-04-23', '4252', 'iooioi', 'oioio'),
(130, '2018-04-23', '333', '', ''),
(131, '2018-04-23', 'o', 'O', 'O'),
(132, '2018-04-23', 'iuhiu', 'unhnh', 'bhhb');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `restful`
--
ALTER TABLE `restful`
  ADD UNIQUE KEY `ID` (`ID`),
  ADD UNIQUE KEY `ID_2` (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `restful`
--
ALTER TABLE `restful`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
