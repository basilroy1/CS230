<?php

include 'conn.php';
// Check connection


$sql = "SELECT * FROM customer";
if ($connection->query($sql)) {
   // $msg = array("status" =>1 , "msg" => "Record Deleted successfully");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($connection);
} 

$result = $connection->query($sql);
    //$records = array();
    while($row = $result->fetch_assoc()){
      $json[]= array("Name" => $row["Name"], "Country" => $row["Country"]);
    }
  
$msg=$json;
  header('content-type: application/json');
  echo json_encode($msg,JSON_PRETTY_PRINT);
@mysqli_close($connection);
?>
