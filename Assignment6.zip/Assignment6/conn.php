<?php

$connection = new mysqli("localhost", "root", "", "assignment6") or die(mysqli_error());

?>