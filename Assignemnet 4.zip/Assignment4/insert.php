<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assignment4";


$start="";
$count="";

if(isset($_GET['btn'])){

$start= $_GET['start']; 
$count= $_GET['Result'];

}
 

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO yoga (User,Score)
VALUES ('$start','$count')";

if ($conn->query($sql) === TRUE) {
    //echo "New record created successfully";
   // header("location: questions.html");
} 
else{
 
    echo "Error: " . $sql . "<br>" . $conn->error;
}
header("location:quiz1.html");
$conn->close();
?>