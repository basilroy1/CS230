
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assignment4";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if(isset($_GET['retrieve'])){

$sql = "SELECT * FROM yoga";
$result = $conn->query($sql);
echo "<table><tr> <th>User</th> <th>Score</th> </tr>";
if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {

        echo "<tr><td> " . $row["User"]. "</td><td>" . $row["Score"]. "</td></tr>";
    }
} 
else {
    echo "0 results";
}

}
$conn->close();
?>
