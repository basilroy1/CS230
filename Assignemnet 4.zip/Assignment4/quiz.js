var count=0;
var total=10;

function correct(){
sessionStorage.setItem('ans1','a');
sessionStorage.setItem('ans2','a');
sessionStorage.setItem('ans3','a');
sessionStorage.setItem('ans4','a');
sessionStorage.setItem('ans5','a');
sessionStorage.setItem('ans6','a');
sessionStorage.setItem('ans7','a');
sessionStorage.setItem('ans8','a');
sessionStorage.setItem('ans9','a');
sessionStorage.setItem('ans10','a');

sessionStorage.setItem('ans11','a');
sessionStorage.setItem('ans12','a');
sessionStorage.setItem('ans13','a');
sessionStorage.setItem('ans14','a');
sessionStorage.setItem('ans15','a');
sessionStorage.setItem('ans16','a');
sessionStorage.setItem('ans17','a');
sessionStorage.setItem('ans18','a');
sessionStorage.setItem('ans19','a');
sessionStorage.setItem('ans20','a');

}


$(document).ready(function(){
	$('.question1').hide();
	$('#prev').hide();
	$('#save').hide();
	$('#res1').hide();
	$('#enter2').hide();

	$('#q1').show();

	$('#q1 #submit2').click(function() {
		
		$('.question1').hide();
		$('#save').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q1');
		$('#q2').fadeIn(250);
		
		return false;

	});

	$('#q2 #submit2').click(function() {
		
		$('.question1').hide();
		$('#enter2').hide();
		$('#save').hide();
		$('#prev').hide();
		$('#res1').hide();
		checkAns('q2');
		$('#q3').fadeIn(250);
		
		return false;

	});


	$('#q3 #submit2').click(function() {
		
		$('.question1').hide();
		$('#prev').hide();
		$('#save').hide();
		$('#enter2').hide();
		$('#res1').hide();
		checkAns('q3');
		$('#q4').fadeIn(250);
		return false;

	});

	$('#q4 #submit2').click(function() {
		
		$('.question1').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q4');
		$('#q5').fadeIn(250);
		return false;

	});

	$('#q5 #submit2').click(function() {
		
		$('.question1').hide();
		$('#save').hide();
		$('#enter2').hide();
		$('#res1').hide();
		$('#prev').hide();
		checkAns('q5');
		$('#q6').fadeIn(250);
		return false;

	});

	$('#q6 #submit2').click(function() {
		
		$('.question1').hide();
		$('#save').hide();
		$('#enter2').hide();
		$('#prev').hide();
		$('#res1').hide();
		checkAns('q6');
		$('#q7').fadeIn(250);
		return false;

	});

	$('#q7 #submit2').click(function() {
		
		$('.question1').hide();
		$('#prev').hide();
		$('#enter2').hide();
		$('#save').hide();
		checkAns('q7');
		$('#q8').fadeIn(250);
		return false;

	});
	$('#q8 #submit2').click(function() {
		
		$('.question1').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		$('#save').hide();
		checkAns('q8');
		$('#q9').fadeIn(250);
		return false;

	});
	$('#q9 #submit2').click(function() {
		
		$('.question1').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#save').hide();
		$('#enter2').hide();
		checkAns('q9');
		$('#q10').fadeIn(250);
		return false;

	});
	$('#q10 #submit2').click(function() {
		
		$('.question1').hide();
	    
		checkAns('q10');
		$('#prev').hide();
		$('#res1').fadeIn(250);
		$('#enter2').fadeIn(250);
		$('#save').fadeIn(250);
		
		return false;

	});
	
});


$(document).ready(function(){
	$('.question').hide();
	$('#prev').hide();
	$('#save').hide();
	$('#res1').hide();
	$('#enter2').hide();

	$('#q11').show();

$('#q11 #submit2').click(function() {
		
		$('question').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q11');
		$('#q12').fadeIn(250);
		return false;

	});
$('#q12 #submit2').click(function() {
		
		$('.question').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q12');
		$('#q13').fadeIn(250);
		return false;

	});

$('#q13 #submit2').click(function() {
		
		$('.question').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q13');
		$('#q14').fadeIn(250);
		return false;

	});
$('#q14 #submit2').click(function() {
		
		$('.question').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q14');
		$('#q15').fadeIn(250);
		return false;

	});
$('#q15 #submit2').click(function() {
		
		$('.question').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q15');
		$('#q16').fadeIn(250);
		return false;

	});
$('#q16 #submit2').click(function() {
		
		$('.question').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q16');
		$('#q17').fadeIn(250);
		return false;

	});
$('#q17 #submit2').click(function() {
		
		$('.question').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q17');
		$('#q18').fadeIn(250);
		return false;

	});
$('#q18 #submit2').click(function() {
		
		$('.question').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q18');
		$('#q19').fadeIn(250);
		return false;

	});
$('#q19 #submit2').click(function() {
		
		$('.question').hide();
		$('#prev').hide();
		$('#res1').hide();
		$('#enter2').hide();
		checkAns('q19');
		$('#q20').fadeIn(250);
		return false;

	});
$('#q20 #submit2').click(function() {
		
		$('.question').hide();
		checkAns('q20');
		$('#prev').hide();

		$('#res1').fadeIn(250);
		$('#enter2').fadeIn(250);
		$('#save').fadeIn(250);
		
		
		return false;

	});
});

function checkAns(q){
if(q=="q1"){
	var submit=$('input[name=q1]:checked').val();
	if(submit==sessionStorage.ans1){
		count++;
	}
	else{
		count+=0;
	}
}

if(q=="q2"){
	var submit=$('input[name=q2]:checked').val();
	if(submit==sessionStorage.ans2){
		count++;
	}
	else{
		count+=0;
	}
}

if(q=="q3"){
	var submit=$('input[name=q3]:checked').val();
	if(submit==sessionStorage.ans3){
		count++;
	}
	else{
		count+=0;
	}
}
if(q=="q4"){
	var submit=$('input[name=q4]:checked').val();
	if(submit==sessionStorage.ans4){
		count++;
	}
	else{
		count+=0;
	}
}
if(q=="q5"){
	var submit=$('input[name=q5]:checked').val();
	if(submit==sessionStorage.ans5){
		count++;
	}
	else{
		count+=0;
	}
}

if(q=="q6"){
	var submit=$('input[name=q6]:checked').val();
	if(submit==sessionStorage.ans6){
		count++;
	}
	else{
		count+=0;
	}
}

if(q=="q7"){
	var submit=$('input[name=q7]:checked').val();
	if(submit==sessionStorage.ans7){
		count++;
	}
	else{
		count+=0;
	}
}
if(q=="q8"){
	var submit=$('input[name=q8]:checked').val();
	if(submit==sessionStorage.ans8){
		count++;
	}
	else{
		count+=0;
	}
}
if(q=="q9"){
	var submit=$('input[name=q9]:checked').val();
	if(submit==sessionStorage.ans9){
		count++;
	}
	else{
		count+=0;
	}
}
if(q=="q10"){
	var submit=$('input[name=q10]:checked').val();
	if(submit==sessionStorage.ans10){
		count++;
	}
	else{
		count+=0;
	}
	$('#h1').text('Your final result is : '+count+ ' / '+total);
	$("#h1").css("text-align","center");
	$("#h1").css("color","#FF7200");

}
if(q=="q11"){
	var submit=$('input[name=q11]:checked').val();
	if(submit==sessionStorage.ans11){
		count++;
	}
	else{
		count+=0;
	}
}

if(q=="q12"){
	var submit=$('input[name=q12]:checked').val();
	if(submit==sessionStorage.ans12){
		count++;
	}
	else{
		count+=0;
	}

}
if(q=="q13"){
	var submit=$('input[name=q13]:checked').val();
	if(submit==sessionStorage.ans13){
		count++;
	}
	else{
		count+=0;
	}

}if(q=="q14"){
	var submit=$('input[name=q14]:checked').val();
	if(submit==sessionStorage.ans14){
		count++;
	}
	else{
		count+=0;
	}

}
if(q=="q15"){
	var submit=$('input[name=q15]:checked').val();
	if(submit==sessionStorage.ans15){
		count++;
	}
	else{
		count+=0;
	}

}

if(q=="q16"){
	var submit=$('input[name=q16]:checked').val();
	if(submit==sessionStorage.ans16){
		count++;
	}
	else{
		count+=0;
	}

}
if(q=="q17"){
	var submit=$('input[name=q17]:checked').val();
	if(submit==sessionStorage.ans17){
		count++;
	}
	else{
		count+=0;
	}

}
if(q=="q18"){
	var submit=$('input[name=q18]:checked').val();
	if(submit==sessionStorage.ans18){
		count++;
	}
	else{
		count+=0;
	}

}
if(q=="q19"){
	var submit=$('input[name=q10]:checked').val();
	if(submit==sessionStorage.ans19){
		count++;
	}
	else{
		count+=0;
	}

}
if(q=="q20"){
	var submit=$('input[name=q20]:checked').val();
	if(submit==sessionStorage.ans20){
		count++;
	}
	else{
		count+=0;
	}
	$('#h1').text('Your final result is : '+count+ ' / '+total);
	$("#h1").css("text-align","center");
	$("#h1").css("color","#900C3F");

}
}
window.addEventListener('load',correct,false);