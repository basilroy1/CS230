<?php include("Delete.php");?>

<!DOCTYPE html>
<html>
<head>

	<title style="align:center"> Assignment 3</title>
	<link rel="stylesheet" type="text/css" href ="style.css">

</head>
<header style="font-size: 40px;background-color: blue; text-align: center; border-radius: 20px;">
	
Single Page Application (PHP) </header>
<body>	
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cs230 a3";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if(isset($_GET['retrieve'])){


$sql = "SELECT * FROM assignment3";
$result = $conn->query($sql);
echo "<table><tr> <th>ID</th> <th>Creator</th> <th>Title</th> <th>Type</th> <th>Identifier</th> <th>Date</th> <th>Language</th> <th>Description</th></tr>";
if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {

        echo "<tr><td> " . $row["id"]. " </td><td>" . $row["creator"]. "</td><td> " . $row["title"]. "</td><td>" . $row["type"]."</td><td>". $row["identifier"]."</td><td>". $row["date"]."</td><td>" . $row["language"]."</td><td>". $row["description"]."</td></tr><br>";
    }
} 
else {
    echo "0 results";
}
//header("location:home.php");
}
$conn->close();
?>


	
	<form id ="insert" action="server.php" method="get">

		<div class="save"> 
			<br>
			<label> ID</label>
			<br/>
			<input type="text" name="ID">
			
		</div>

		<div class="save"> 
			
			<label>Creator</label>
			<br/>
			<input type="text" name="creator">
		</div>

		<div class="save"> 
			
			<label>title</label>
			<br/>
			<input type="text" name="title">
		</div>
		<div class="save"> 
			
			<label>type</label>
			<br/>
			<input type="text" name="type">
		</div>

		<div class="save"> 
			
			<label>identifier</label>
			<br/>
			<input type="text" name="identifier">
		</div>
		<div class="save"> 
			
			<label>language</label>
			<br/>
			<input type="text" name="language">
		</div>
		
		
		<div class="save"> 
			
			<label>Date</label>
			
			<br/>
			<input type="date" name="date">
		</div>
		<div class="save"> 
			
			<label>description</label>
			<br/>
			<input type="text" name="description">
		</div>
		<div class="save">
			<br/>
			<button  type="text" name="insert" class="save">INSERT</button>

		</div>
		
	</form>

	<form id="update"action="update.php">
			<div class="save"> 
			<label> ID</label>
			<br/>
			<input type="text" name="ID">
			
		</div>

		<div class="save"> 
			
			<label>Creator</label>
			<br/>
			<input type="text" name="creator">
		</div>

		<div class="save"> 
			
			<label>title</label>
			<br/>
			<input type="text" name="title">
		</div>
		<div class="save"> 
			
			<label>type</label>
			<br/>
			<input type="text" name="type">
		</div>

		<div class="save"> 
			
			<label>identifier</label>
			<br/>
			<input type="text" name="identifier">
		</div>
		<div class="save"> 
			
			<label>language</label>
			<br/>
			<input type="text" name="language">
		</div>
		
		
		<div class="save"> 
			
			<label>Date</label>
			
			<br/>
			<input type="date" name="date">
		</div>
		<div class="save"> 
			
			<label>description</label>
			<br/>
			<input type="text" name="description">
		</div>
		<div class="save">
			<br/>
			<button  type="text" name="update" class="save">Update</button>

		</div>
	</form>

	<form id="delete"action="Delete.php">

<div class="save"> 
</div> 

			<br/>
			<label id="r">Enter ID</label>
			<br/>
			<input type="text" name="ID">
		</div>

<div class="save">
			<br/>
			<button  type="text" name="delete" class="delte">Delete</button>

		</div>

	</form>
<form id="getdata"action="home.php">
	<button type ="text" name="retrieve">GET DATA</button>
</form>

<form id="undo" action="home.php">
	<button type="text" name="undo">Undo</button>
</form>
</body>
</html>
