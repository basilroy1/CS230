 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cs230 a3";

$_id="";
$_creator="";
$_title="";
$_type="";
$_identifier="";
$_date ="";
$_language="";
$_description="";

if(isset($_GET['insert'])){

$_id = $_GET['ID']; 
$_creator = $_GET['creator']; 
$_title = $_GET['title']; 
$_type = $_GET['type']; 
$_identifier = $_GET['identifier']; 
$_date = $_GET['date']; 
$_language = $_GET['language']; 
$_description = $_GET['description']; 

}
// Create  connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO assignment3 (id, creator, title,type,identifier,date,language,description)
VALUES ('$_id','$_creator','$_title','$_type','$_identifier','$_date','$_language','$_description')";

if ($conn->query($sql) === TRUE) {
    //echo "New record created successfully";
    header("location: home.php");
} 
else {
 
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>