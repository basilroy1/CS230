 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cs230 a3";

$_id="";


if(isset($_GET['delete'])){

$_id = $_GET['ID']; 


}
// Create  connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "DELETE FROM assignment3 WHERE id='$_id'";



if(isset($_GET['undo'])){
	
	echo "transcation rollabck";
}
else{
	
	echo"succes";
}
if ($conn->query($sql) === TRUE) {
   
    //header("location: home.php");        	/////NOTE WHEN I PUT THIS IN FOR THE DELTE BUTTIN THE PAGE SAYS NOT AVAILAble THERFORE I CANT REDIRECT THE DELETE BIT TO THE HOME.PHP
} 
else {
 
   // echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>