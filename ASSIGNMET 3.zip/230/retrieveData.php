<!DOCTYPE HTML>
<html>



<body>

<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cs230 a3";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if(isset($_GET['retrieve'])){


$sql = "SELECT * FROM assignment3";
$result = $conn->query($sql);
echo "<table><tr> <th>ID</th> <th>Creator</th> <th>Title</th> <th>Type</th> <th>Identifier</th> <th>Date</th> <th>Language</th> <th>Description</th></tr>";
if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {

        echo "<tr><td> " . $row["id"]. " </td><td>" . $row["creator"]. "</td><td> " . $row["title"]. "</td><td>" . $row["type"]."</td><td>". $row["identifier"]."</td><td>". $row["date"]."</td><td>" . $row["language"]."</td><td>". $row["description"]."</td></tr><br>";
    }
} 
else {
    echo "0 results";
}
header("location:home.php");
}
$conn->close();
?>


</body>
</html>