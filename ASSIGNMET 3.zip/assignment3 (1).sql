-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2018 at 01:47 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cs230 a3`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignment3`
--

CREATE TABLE `assignment3` (
  `id` int(5) NOT NULL,
  `creator` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `identifier` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `language` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment3`
--

INSERT INTO `assignment3` (`id`, `creator`, `title`, `type`, `identifier`, `date`, `language`, `description`) VALUES
(987643, '', '', '', '', '0000-00-00', '', 'basli is the best'),
(7, 'ooo', 'lolol', 'yuoppppa', '12345567', '0000-00-00', '', ''),
(999, '', '', '', '', '2018-03-08', '', 'bday'),
(6, '', 'helloo', '', '', '0000-00-00', 'iihs', ''),
(5555, '', '', '', '', '0000-00-00', '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
